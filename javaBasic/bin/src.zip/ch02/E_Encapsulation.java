package ch02;

public class E_Encapsulation {

	public static void main(String[] args) {
		
	}

}
